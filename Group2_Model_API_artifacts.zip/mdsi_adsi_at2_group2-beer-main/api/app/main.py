from fastapi import FastAPI, Query
from fastapi.encoders import jsonable_encoder
from starlette.responses import JSONResponse
import pandas as pd
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
import joblib
from joblib import load
import os
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OrdinalEncoder
from typing import List, Optional

app = FastAPI()

# Load the model
model = torch.load('/models/pytorch.pt')
# Load the pipeline and encoder for features preprocessing
pipeline_features = joblib.load('/models/pipeline_features.joblib')
# Load encoder for target
encoder_target = joblib.load('/models/encoder_target.joblib')

# API documentation
api_docs = {
        'Description': "The aim for this project is to build a custom neural networks model that will accurately predict a type of beer based on some rating criterias such as appearance, aroma, palate or taste.",
        'Endpoints': {
                        "‘/’ (GET)": "Displaying a brief description of the project objectives, list of endpoints, expected input parameters and output format of the model, link to the Github repo related to this project",
                        "/health/’ (GET)": "Returning status code 200 with a string with a welcome message of your choice",
                        "‘/beer/type/’ (POST)" : "Returning prediction for a single input only",
                        "/beers/type/’ (POST)" : "Returning predictions for a multiple inputs",
                        "‘/model/architecture/’ (GET)" : "Displaying the architecture of your Neural Networks (listing of all layers with their types"
                    },
        'Model inputs' : {
                            "brewery_name (str)": "Name of brewery",
                            "review_aroma (float)": "Score given by reviewer regarding beer aroma",
                            "review_appearance (float)": "Score given by reviewer regarding beer appearance",
                            "review_palate (float)": "Score given by reviewer regarding beer palate",
                            "review_taste (float)": "Score given by reviewer regarding beer taste",
                            "beer_abv (float)": "Alcohol by volume measure"
                          },
        'Model outputs' : {
                            "beer_style (str)": "Type of beer"
                          },
        'Github Repo' : "https://github.com/bennylylee/mdsi_adsi_at2_group2-beer"
    }

@app.get('/')
def getRoot():
    """Displaying a brief description of the project objectives, list of endpoints, expected input parameters and output format of the model, link to the Github repo related to this project

    Returns:
        JSON : project description
    """    
    content = jsonable_encoder(api_docs)
    return JSONResponse(content=content)

@app.get('/health', status_code=200)
def healthcheck():
    """Returning status code 200 with a string with a welcome message of your choice

    """    
    return 'Health check passed!'

@app.get('/model/architecture/')
def get_architecture():
    """Displaying the architecture of your Neural Networks (listing of all layers with their types

    Returns:
       JSON: Model architecture
    """    
    return dict(model._modules)

@app.post('/beer/type/')
def predict_single_record(brewery_name: str,
                          review_aroma: float,
                          review_appearance: float,
                          review_palate: float,
                          review_taste: float,
                          beer_abv: float,
                         ):
    """Returning prediction for a single input only

    Args:
        brewery_name (str): Name of brewery
        review_aroma (float): Score given by reviewer regarding beer aroma
        review_appearance (float): Score given by reviewer regarding beer appearance
        review_palate (float): Score given by reviewer regarding beer palate
        review_taste (float): Score given by reviewer regarding beer taste
        beer_abv (float): Alcohol by volume measure

    Returns:
        Beer type (str): Type of beer
    """    
    result=pred_beer_type(brewery_name, review_aroma, review_appearance, review_palate, review_taste, beer_abv ) 
    return JSONResponse(result[0])

@app.post('/beers/type/')
def predict_multiple_records(brewery_name: List[str] = Query(None),
                          review_aroma: List[float] = Query(None),
                          review_appearance: List[float] = Query(None),
                          review_palate: List[float] = Query(None),
                          review_taste: List[float] = Query(None),
                          beer_abv: List[float] = Query(None),
                         ):
    """Returning predictions for a multiple inputs

    Args:
        brewery_name (List[str], optional): Name of brewery. Defaults to Query(None).
        review_aroma (List[float], optional): Score given by reviewer regarding beer aroma. Defaults to Query(None).
        review_appearance (List[float], optional): Score given by reviewer regarding beer appearance. Defaults to Query(None).
        review_palate (List[float], optional): Score given by reviewer regarding beer palate. Defaults to Query(None).
        review_taste (List[float], optional): Score given by reviewer regarding beer taste. Defaults to Query(None).
        beer_abv (List[float], optional): Alcohol by volume measure. Defaults to Query(None).

    Returns:
        Beer type (list): A list of predicated beer types
    """    
   
    result_list = []
    for i in range(len(brewery_name)):
        result = pred_beer_type(brewery_name[i],
                                       review_aroma[i],
                                       review_appearance[i],
                                       review_palate[i],
                                       review_taste[i],
                                       beer_abv[i]
                                      )
        result_list.append(result[0])
    
    return result_list

def format_features(brewery_name: float, 
                    review_aroma: float, 
                    review_appearance: float, 
                    review_palate: float, 
                    review_taste: float, 
                    beer_abv: float):
    """Convert the input parameters to a dictionary

    Args:
        brewery_name (float): Name of brewery. 
        review_aroma (float): Score given by reviewer regarding beer aroma. 
        review_appearance (float): Score given by reviewer regarding beer appearance
        review_palate (float): Score given by reviewer regarding beer palate.
        review_taste (float): Score given by reviewer regarding beer taste.
        beer_abv (float): Alcohol by volume measure.

    Returns:
        Dictionary (dict): Dictionary of input fields
    """  
    return {
  	'brewery_name': [brewery_name],
    'review_aroma': [review_aroma],
    'review_appearance': [review_appearance],
    'review_palate': [review_palate],
    'review_taste': [review_taste],
    'beer_abv': [beer_abv]
    }


def pred_beer_type(brewery_name: str,
                   review_aroma: float,
                   review_appearance: float,
                   review_palate: float,
                   review_taste: float,
                    beer_abv: float,
                         ):
    """Predicting beer type(s) based on given input features

    Args:
        df_inputs (Data frame): Dataframe of input features

    Returns:
        beer_type (array): A list of predicated beer types
    """    
    dict_inputs = format_features(brewery_name, review_aroma, review_appearance, review_palate, review_taste, beer_abv )

    df_inputs = pd.DataFrame(dict_inputs)
    
    # Encoding input features
    df_transformed=pipeline_features.transform(df_inputs)
    
    # Use CPU
    device= torch.device('cpu')
    
    # Convert to tensor
    df_tensor = torch.Tensor(np.array(df_transformed)).to(device)
    
    # Perform the prediction
    pred_beer_style = model(df_tensor).argmax(1)
    
    # Use the target encode to convert the model score to beer_style
    return encoder_target.inverse_transform(pred_beer_style.tolist())