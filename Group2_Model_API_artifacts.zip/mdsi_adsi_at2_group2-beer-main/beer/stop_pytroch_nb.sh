#!/bin/bash

docker stop pytorch_notebook
