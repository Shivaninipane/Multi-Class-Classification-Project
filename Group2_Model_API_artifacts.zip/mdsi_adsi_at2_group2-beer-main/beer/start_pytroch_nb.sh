#!/bin/bash

PROJECT_DIR="/Users/bennylee/Downloads/__mdsi_adsi_at2_group2-beer"

docker run  -dit --rm --name pytorch_notebook -p 8888:8888 -e JUPYTER_ENABLE_LAB=yes -v ${PROJECT_DIR}:/home/jovyan/work -v ${PROJECT_DIR}/src:/home/jovyan/work/src pytorch-notebook:latest

sleep 5

docker logs --tail 50 pytorch_notebook
